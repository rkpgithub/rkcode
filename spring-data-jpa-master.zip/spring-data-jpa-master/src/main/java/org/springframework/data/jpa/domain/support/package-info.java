/**
 * Implementation classes for auditing with JPA.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.domain.support;
