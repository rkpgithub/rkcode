/**
 * CDI support for Spring Data JPA Repositories.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.repository.cdi;
