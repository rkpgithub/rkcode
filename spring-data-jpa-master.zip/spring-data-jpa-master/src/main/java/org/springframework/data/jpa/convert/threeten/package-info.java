/**
 * Spring Data JPA specific JSR-310 converters.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.convert.threeten;
