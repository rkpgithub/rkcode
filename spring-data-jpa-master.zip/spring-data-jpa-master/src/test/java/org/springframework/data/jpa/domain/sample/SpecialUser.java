package org.springframework.data.jpa.domain.sample;

import javax.persistence.Entity;

/**
 * @author Oliver Gierke
 */
@Entity
public class SpecialUser extends User {

}
